# 🎯 FocusFlow — App di Produttività

Un'app completa di produttività con gestione task, note e calendario con notifiche push. Costruita con **Expo + React Native**, pronta per il Play Store.

---

## 📱 Funzionalità

### ✅ Task Manager
- Aggiunta task con priorità (Bassa / Media / Alta)
- Scadenze con date
- Filtri: Tutti / Attivi / Completati
- Barra di progresso visiva
- Notifica di conferma all'aggiunta

### 📝 Note
- Editor full-screen con titolo e corpo
- Colori personalizzati per ogni nota (6 colori)
- Griglia a 2 colonne
- Ricerca in tempo reale
- Long-press per eliminare

### 📅 Calendario
- Vista mensile interattiva
- Punti colorati sui giorni con eventi
- Aggiunta eventi con orario
- **Reminder automatico 30 minuti prima** di ogni evento
- Long-press per eliminare evento

---

## 🚀 Setup & Sviluppo

### 1. Prerequisiti
```bash
node >= 18
npm >= 9
```

### 2. Installa le dipendenze
```bash
cd FocusFlow
npm install
```

### 3. Avvia in sviluppo
```bash
npm start
# oppure
npx expo start
```
Scansiona il QR con l'app **Expo Go** (disponibile sul Play Store) per vedere l'app sul tuo telefono istantaneamente.

---

## 🏗️ Build per Play Store

### 1. Installa EAS CLI
```bash
npm install -g eas-cli
```

### 2. Crea account Expo
Registrati su [expo.dev](https://expo.dev)

### 3. Configura il progetto
```bash
eas login
eas build:configure
```

### 4. Aggiorna app.json
Modifica questi valori in `app.json`:
```json
"android": {
  "package": "com.tuonome.focusflow"   // Deve essere unico sul Play Store
}
```

### 5. Build APK (test)
```bash
npm run build:preview
```

### 6. Build AAB (Play Store)
```bash
npm run build:android
# oppure
eas build --platform android --profile production
```

EAS Cloud compila il progetto sui loro server. Riceverai un link per scaricare l'`.aab` pronto per il Play Store.

---

## 📤 Pubblicazione sul Play Store

1. Crea un account **Google Play Console** ($25 una tantum): [play.google.com/console](https://play.google.com/console)
2. Vai su **"Crea app"** e segui la procedura
3. Carica l'`.aab` nella sezione **"Test > Test interno"**
4. Compila: descrizione, screenshot, icone, privacy policy
5. Invia per revisione → Pubblicazione (solitamente 1-3 giorni)

### Screenshot obbligatori
- Almeno 2 screenshot del telefono (min 320px, max 3840px)
- Icona app: 512×512 PNG

---

## 🎨 Personalizzazione

### Cambiare nome app
In `app.json`:
```json
"name": "Il tuo nome app"
```

### Cambiare colori
In `constants/theme.js`:
```js
primary: '#FF6B35',   // Colore principale (arancione)
accent: '#E94560',    // Colore accentuazione (rosso)
```

### Aggiungere icona
Sostituisci i file nella cartella `assets/`:
- `icon.png` — 1024×1024 PNG
- `splash.png` — 1242×2436 PNG
- `adaptive-icon.png` — 1024×1024 PNG (Android)

---

## 🗂️ Struttura Progetto

```
FocusFlow/
├── App.js                    # Navigazione principale
├── app.json                  # Configurazione Expo
├── eas.json                  # Configurazione build
├── package.json
├── babel.config.js
├── assets/                   # Icone e splash screen
├── constants/
│   └── theme.js              # Colori e stile globale
├── screens/
│   ├── TodoScreen.js         # Task manager
│   ├── NotesScreen.js        # Note
│   └── CalendarScreen.js     # Calendario + eventi
└── utils/
    ├── storage.js            # Persistenza dati (AsyncStorage)
    └── notifications.js      # Gestione notifiche push
```

---

## 💡 Prossimi sviluppi (idee)

- [ ] Widget per la schermata home Android
- [ ] Sincronizzazione con Google Calendar
- [ ] Temi chiari/scuri
- [ ] Statistiche produttività settimanale
- [ ] Backup su Google Drive

---

## 📄 Licenza

MIT — Fai quello che vuoi con il codice!
