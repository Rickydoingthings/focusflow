import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  FlatList,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Modal,
  Platform,
  Animated,
  Alert,
  KeyboardAvoidingView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { COLORS, SPACING } from '../constants/theme';
import { Storage, KEYS } from '../utils/storage';
import { scheduleTaskReminder, cancelNotification, sendInstantNotification } from '../utils/notifications';

const PRIORITIES = [
  { label: 'Low', color: '#4CAF50', icon: 'arrow-down' },
  { label: 'Medium', color: '#FFC107', icon: 'remove' },
  { label: 'High', color: '#E94560', icon: 'arrow-up' },
];

const FILTERS = ['All', 'Active', 'Completed'];

function TaskItem({ task, onToggle, onDelete, fadeAnim }) {
  const priority = PRIORITIES[task.priority ?? 1];
  const scale = useRef(new Animated.Value(1)).current;

  const handleToggle = () => {
    Animated.sequence([
      Animated.timing(scale, { toValue: 0.95, duration: 80, useNativeDriver: true }),
      Animated.timing(scale, { toValue: 1, duration: 80, useNativeDriver: true }),
    ]).start();
    onToggle(task.id);
  };

  return (
    <Animated.View style={[styles.taskItem, { transform: [{ scale }] }]}>
      <TouchableOpacity onPress={handleToggle} style={styles.checkbox}>
        {task.completed ? (
          <View style={[styles.checkboxFilled, { backgroundColor: COLORS.primary }]}>
            <Ionicons name="checkmark" size={14} color="#fff" />
          </View>
        ) : (
          <View style={[styles.checkboxEmpty, { borderColor: priority.color }]} />
        )}
      </TouchableOpacity>

      <View style={styles.taskContent}>
        <Text style={[styles.taskTitle, task.completed && styles.taskCompleted]}>
          {task.title}
        </Text>
        <View style={styles.taskMeta}>
          <View style={[styles.priorityBadge, { backgroundColor: priority.color + '22' }]}>
            <Ionicons name={priority.icon} size={10} color={priority.color} />
            <Text style={[styles.priorityText, { color: priority.color }]}>{priority.label}</Text>
          </View>
          {task.dueDate && (
            <Text style={styles.dueDate}>
              📅 {new Date(task.dueDate).toLocaleDateString('it-IT', { day: '2-digit', month: 'short' })}
            </Text>
          )}
        </View>
      </View>

      <TouchableOpacity onPress={() => onDelete(task.id)} style={styles.deleteBtn}>
        <Ionicons name="trash-outline" size={18} color={COLORS.muted} />
      </TouchableOpacity>
    </Animated.View>
  );
}

export default function TodoScreen() {
  const [todos, setTodos] = useState([]);
  const [filter, setFilter] = useState('All');
  const [modalVisible, setModalVisible] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newPriority, setNewPriority] = useState(1);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [dueDate, setDueDate] = useState(null);
  const inputRef = useRef(null);

  useEffect(() => {
    loadTodos();
  }, []);

  async function loadTodos() {
    const saved = await Storage.get(KEYS.TODOS);
    if (saved) setTodos(saved);
  }

  async function saveTodos(newTodos) {
    setTodos(newTodos);
    await Storage.set(KEYS.TODOS, newTodos);
  }

  async function addTodo() {
    if (!newTitle.trim()) return;

    const task = {
      id: Date.now().toString(),
      title: newTitle.trim(),
      completed: false,
      priority: newPriority,
      dueDate: dueDate?.toISOString() ?? null,
      createdAt: new Date().toISOString(),
      notificationId: null,
    };

    if (dueDate) {
      const notifId = await scheduleTaskReminder(task, dueDate);
      task.notificationId = notifId;
    }

    await saveTodos([task, ...todos]);
    setNewTitle('');
    setDueDate(null);
    setNewPriority(1);
    setModalVisible(false);
    await sendInstantNotification('✅ Task Added', `"${task.title}" added to your list`);
  }

  async function toggleTodo(id) {
    const updated = todos.map(t => {
      if (t.id === id) return { ...t, completed: !t.completed };
      return t;
    });
    await saveTodos(updated);
  }

  async function deleteTodo(id) {
    const task = todos.find(t => t.id === id);
    if (task?.notificationId) await cancelNotification(task.notificationId);
    Alert.alert('Delete Task', 'Remove this task?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive',
        onPress: async () => {
          await saveTodos(todos.filter(t => t.id !== id));
        }
      }
    ]);
  }

  const filtered = todos.filter(t => {
    if (filter === 'Active') return !t.completed;
    if (filter === 'Completed') return t.completed;
    return true;
  });

  const completedCount = todos.filter(t => t.completed).length;
  const progress = todos.length > 0 ? completedCount / todos.length : 0;

  return (
    <View style={styles.container}>
      {/* Stats bar */}
      <View style={styles.statsBar}>
        <View style={styles.statsText}>
          <Text style={styles.statsNumber}>{todos.length - completedCount}</Text>
          <Text style={styles.statsLabel}>remaining</Text>
        </View>
        <View style={styles.progressBarBg}>
          <View style={[styles.progressBarFill, { width: `${progress * 100}%` }]} />
        </View>
        <View style={styles.statsText}>
          <Text style={[styles.statsNumber, { color: COLORS.success }]}>{completedCount}</Text>
          <Text style={styles.statsLabel}>done</Text>
        </View>
      </View>

      {/* Filters */}
      <View style={styles.filters}>
        {FILTERS.map(f => (
          <TouchableOpacity
            key={f}
            style={[styles.filterBtn, filter === f && styles.filterBtnActive]}
            onPress={() => setFilter(f)}
          >
            <Text style={[styles.filterText, filter === f && styles.filterTextActive]}>{f}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* List */}
      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TaskItem task={item} onToggle={toggleTodo} onDelete={deleteTodo} />
        )}
        contentContainerStyle={{ padding: SPACING.md, paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>🎯</Text>
            <Text style={styles.emptyText}>No tasks here</Text>
            <Text style={styles.emptySubtext}>Tap + to add your first task</Text>
          </View>
        }
      />

      {/* FAB */}
      <TouchableOpacity style={styles.fab} onPress={() => setModalVisible(true)}>
        <Ionicons name="add" size={30} color="#fff" />
      </TouchableOpacity>

      {/* Add Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent
        onShow={() => setTimeout(() => inputRef.current?.focus(), 100)}
      >
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setModalVisible(false)} />
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>New Task</Text>

            <TextInput
              ref={inputRef}
              style={styles.input}
              placeholder="What needs to be done?"
              placeholderTextColor={COLORS.muted}
              value={newTitle}
              onChangeText={setNewTitle}
              onSubmitEditing={addTodo}
              returnKeyType="done"
            />

            <Text style={styles.sectionLabel}>Priority</Text>
            <View style={styles.priorityRow}>
              {PRIORITIES.map((p, i) => (
                <TouchableOpacity
                  key={i}
                  style={[
                    styles.priorityOpt,
                    { borderColor: p.color },
                    newPriority === i && { backgroundColor: p.color },
                  ]}
                  onPress={() => setNewPriority(i)}
                >
                  <Text style={[styles.priorityOptText, newPriority === i && { color: '#fff' }]}>
                    {p.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>

            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowDatePicker(true)}>
              <Ionicons name="calendar-outline" size={18} color={COLORS.primary} />
              <Text style={styles.dateBtnText}>
                {dueDate ? dueDate.toLocaleDateString('it-IT') : 'Set due date (optional)'}
              </Text>
              {dueDate && (
                <TouchableOpacity onPress={() => setDueDate(null)}>
                  <Ionicons name="close-circle" size={18} color={COLORS.muted} />
                </TouchableOpacity>
              )}
            </TouchableOpacity>

            {showDatePicker && (
              <DateTimePicker
                value={dueDate || new Date()}
                mode="date"
                display="default"
                minimumDate={new Date()}
                onChange={(e, d) => {
                  setShowDatePicker(false);
                  if (d) setDueDate(d);
                }}
              />
            )}

            <TouchableOpacity
              style={[styles.addBtn, !newTitle.trim() && styles.addBtnDisabled]}
              onPress={addTodo}
              disabled={!newTitle.trim()}
            >
              <Text style={styles.addBtnText}>Add Task</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.darker },
  statsBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.md,
    backgroundColor: COLORS.surface,
    gap: SPACING.md,
  },
  statsText: { alignItems: 'center', minWidth: 44 },
  statsNumber: { fontSize: 20, fontWeight: '800', color: COLORS.primary },
  statsLabel: { fontSize: 10, color: COLORS.muted, textTransform: 'uppercase', letterSpacing: 0.5 },
  progressBarBg: {
    flex: 1, height: 6, backgroundColor: COLORS.border, borderRadius: 3, overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%', backgroundColor: COLORS.primary, borderRadius: 3,
  },
  filters: {
    flexDirection: 'row',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    gap: SPACING.sm,
    backgroundColor: COLORS.darker,
  },
  filterBtn: {
    paddingHorizontal: SPACING.md,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: COLORS.surface,
  },
  filterBtnActive: { backgroundColor: COLORS.primary },
  filterText: { color: COLORS.muted, fontSize: 13, fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  taskItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: COLORS.surface,
    borderRadius: 14,
    padding: SPACING.md,
    marginBottom: SPACING.sm,
    gap: SPACING.sm,
  },
  checkbox: { width: 28, height: 28, justifyContent: 'center', alignItems: 'center' },
  checkboxEmpty: { width: 22, height: 22, borderRadius: 11, borderWidth: 2 },
  checkboxFilled: { width: 22, height: 22, borderRadius: 11, justifyContent: 'center', alignItems: 'center' },
  taskContent: { flex: 1 },
  taskTitle: { color: COLORS.text, fontSize: 15, fontWeight: '600', marginBottom: 4 },
  taskCompleted: { textDecorationLine: 'line-through', color: COLORS.muted },
  taskMeta: { flexDirection: 'row', gap: SPACING.sm, alignItems: 'center' },
  priorityBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    paddingHorizontal: 7, paddingVertical: 2, borderRadius: 8,
  },
  priorityText: { fontSize: 10, fontWeight: '700' },
  dueDate: { fontSize: 11, color: COLORS.muted },
  deleteBtn: { padding: 6 },
  emptyState: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 48, marginBottom: SPACING.md },
  emptyText: { color: COLORS.text, fontSize: 18, fontWeight: '700' },
  emptySubtext: { color: COLORS.muted, marginTop: 4 },
  fab: {
    position: 'absolute', bottom: 24, right: 24,
    width: 60, height: 60, borderRadius: 30,
    backgroundColor: COLORS.primary,
    justifyContent: 'center', alignItems: 'center',
    elevation: 8,
    shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 8,
  },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)' },
  modalSheet: {
    backgroundColor: COLORS.surface,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: SPACING.lg, paddingBottom: 40,
  },
  modalHandle: {
    width: 40, height: 4, backgroundColor: COLORS.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: SPACING.md,
  },
  modalTitle: { color: COLORS.text, fontSize: 20, fontWeight: '800', marginBottom: SPACING.md },
  input: {
    backgroundColor: COLORS.darker, color: COLORS.text,
    borderRadius: 12, padding: SPACING.md,
    fontSize: 16, marginBottom: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border,
  },
  sectionLabel: { color: COLORS.muted, fontSize: 12, fontWeight: '700', textTransform: 'uppercase', marginBottom: 8 },
  priorityRow: { flexDirection: 'row', gap: SPACING.sm, marginBottom: SPACING.md },
  priorityOpt: {
    flex: 1, paddingVertical: 10, borderRadius: 10,
    borderWidth: 2, alignItems: 'center',
  },
  priorityOptText: { color: COLORS.muted, fontWeight: '700' },
  dateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.darker, borderRadius: 12, padding: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border, marginBottom: SPACING.md,
  },
  dateBtnText: { flex: 1, color: COLORS.textSecondary, fontSize: 15 },
  addBtn: {
    backgroundColor: COLORS.primary, borderRadius: 14,
    padding: SPACING.md, alignItems: 'center', marginTop: SPACING.sm,
  },
  addBtnDisabled: { opacity: 0.4 },
  addBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
