export const COLORS = {
  primary: '#FF6B35',
  primaryLight: '#FF8C5A',
  dark: '#1A1A2E',
  darker: '#0F0F1A',
  surface: '#16213E',
  surfaceLight: '#1E2D4A',
  accent: '#E94560',
  accentLight: '#F06070',
  success: '#4CAF50',
  warning: '#FFC107',
  text: '#EAEAEA',
  textSecondary: '#B0BAC8',
  muted: '#8892A4',
  border: '#2A3A5C',
};

export const FONTS = {
  regular: 'System',
  bold: 'System',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};
