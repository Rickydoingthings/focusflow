import React, { useState, useEffect } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  Modal, TextInput, KeyboardAvoidingView, Platform, Alert, ScrollView,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import DateTimePicker from '@react-native-community/datetimepicker';
import { COLORS, SPACING } from '../constants/theme';
import { Storage, KEYS } from '../utils/storage';
import { scheduleEventReminder, cancelNotification } from '../utils/notifications';

const MONTH_NAMES = ['Gen', 'Feb', 'Mar', 'Apr', 'Mag', 'Giu', 'Lug', 'Ago', 'Set', 'Ott', 'Nov', 'Dic'];
const DAY_NAMES = ['Dom', 'Lun', 'Mar', 'Mer', 'Gio', 'Ven', 'Sab'];

function getDaysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

function getFirstDayOfMonth(year, month) {
  return new Date(year, month, 1).getDay();
}

export default function CalendarScreen() {
  const [events, setEvents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewDate, setViewDate] = useState(new Date());
  const [modalVisible, setModalVisible] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [eventDate, setEventDate] = useState(new Date());
  const [showTimePicker, setShowTimePicker] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);

  useEffect(() => { loadEvents(); }, []);

  async function loadEvents() {
    const saved = await Storage.get(KEYS.EVENTS);
    if (saved) setEvents(saved);
  }

  async function saveEvent() {
    if (!newTitle.trim()) return;

    const now = new Date().toISOString();
    let updated;

    if (editingEvent) {
      if (editingEvent.notificationId) await cancelNotification(editingEvent.notificationId);
      const updatedEvent = {
        ...editingEvent,
        title: newTitle,
        description: newDesc,
        date: eventDate.toISOString(),
      };
      const notifId = await scheduleEventReminder(updatedEvent);
      updatedEvent.notificationId = notifId;
      updated = events.map(e => e.id === editingEvent.id ? updatedEvent : e);
    } else {
      const newEvent = {
        id: Date.now().toString(),
        title: newTitle,
        description: newDesc,
        date: eventDate.toISOString(),
        createdAt: now,
        notificationId: null,
      };
      const notifId = await scheduleEventReminder(newEvent);
      newEvent.notificationId = notifId;
      updated = [...events, newEvent];
    }

    setEvents(updated);
    await Storage.set(KEYS.EVENTS, updated);
    closeModal();
  }

  function closeModal() {
    setModalVisible(false);
    setEditingNote(null);
    setNewTitle('');
    setNewDesc('');
    setEventDate(selectedDate);
  }

  // Fix typo in closeModal
  function openNew() {
    setEditingEvent(null);
    setNewTitle('');
    setNewDesc('');
    setEventDate(selectedDate);
    setModalVisible(true);
  }

  function openEdit(event) {
    setEditingEvent(event);
    setNewTitle(event.title);
    setNewDesc(event.description || '');
    setEventDate(new Date(event.date));
    setModalVisible(true);
  }

  async function deleteEvent(id) {
    const event = events.find(e => e.id === id);
    Alert.alert('Delete Event', 'Remove this event?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive',
        onPress: async () => {
          if (event?.notificationId) await cancelNotification(event.notificationId);
          const updated = events.filter(e => e.id !== id);
          setEvents(updated);
          await Storage.set(KEYS.EVENTS, updated);
        }
      }
    ]);
  }

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);

  const selectedDateStr = selectedDate.toDateString();
  const dayEvents = events.filter(e => new Date(e.date).toDateString() === selectedDateStr)
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  function hasEvent(day) {
    const d = new Date(year, month, day).toDateString();
    return events.some(e => new Date(e.date).toDateString() === d);
  }

  function prevMonth() {
    setViewDate(new Date(year, month - 1, 1));
  }

  function nextMonth() {
    setViewDate(new Date(year, month + 1, 1));
  }

  function selectDay(day) {
    setSelectedDate(new Date(year, month, day));
  }

  const isToday = (day) => {
    const today = new Date();
    return day === today.getDate() && month === today.getMonth() && year === today.getFullYear();
  };

  const isSelected = (day) => {
    return day === selectedDate.getDate() && month === selectedDate.getMonth() && year === selectedDate.getFullYear();
  };

  return (
    <View style={styles.container}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Month header */}
        <View style={styles.monthHeader}>
          <TouchableOpacity onPress={prevMonth} style={styles.navBtn}>
            <Ionicons name="chevron-back" size={22} color={COLORS.text} />
          </TouchableOpacity>
          <Text style={styles.monthTitle}>{MONTH_NAMES[month]} {year}</Text>
          <TouchableOpacity onPress={nextMonth} style={styles.navBtn}>
            <Ionicons name="chevron-forward" size={22} color={COLORS.text} />
          </TouchableOpacity>
        </View>

        {/* Day names */}
        <View style={styles.dayNames}>
          {DAY_NAMES.map(d => (
            <Text key={d} style={styles.dayName}>{d}</Text>
          ))}
        </View>

        {/* Calendar grid */}
        <View style={styles.grid}>
          {Array(firstDay).fill(null).map((_, i) => (
            <View key={`empty-${i}`} style={styles.cell} />
          ))}
          {Array(daysInMonth).fill(null).map((_, i) => {
            const day = i + 1;
            const today = isToday(day);
            const selected = isSelected(day);
            const hasEv = hasEvent(day);
            return (
              <TouchableOpacity
                key={day}
                style={[
                  styles.cell,
                  today && styles.cellToday,
                  selected && styles.cellSelected,
                ]}
                onPress={() => selectDay(day)}
              >
                <Text style={[
                  styles.cellText,
                  today && styles.cellTextToday,
                  selected && styles.cellTextSelected,
                ]}>
                  {day}
                </Text>
                {hasEv && <View style={[styles.eventDot, selected && { backgroundColor: '#fff' }]} />}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Selected day events */}
        <View style={styles.eventsSection}>
          <View style={styles.eventsSectionHeader}>
            <Text style={styles.eventsTitle}>
              {selectedDate.toLocaleDateString('it-IT', { weekday: 'long', day: 'numeric', month: 'long' })}
            </Text>
            <TouchableOpacity onPress={openNew} style={styles.addEventBtn}>
              <Ionicons name="add" size={20} color={COLORS.primary} />
              <Text style={styles.addEventText}>Add</Text>
            </TouchableOpacity>
          </View>

          {dayEvents.length === 0 ? (
            <View style={styles.noEvents}>
              <Text style={styles.noEventsText}>No events for this day</Text>
            </View>
          ) : (
            dayEvents.map(event => (
              <TouchableOpacity
                key={event.id}
                style={styles.eventItem}
                onPress={() => openEdit(event)}
                onLongPress={() => deleteEvent(event.id)}
              >
                <View style={[styles.eventTime, { backgroundColor: COLORS.primary + '22' }]}>
                  <Ionicons name="time-outline" size={14} color={COLORS.primary} />
                  <Text style={styles.eventTimeText}>
                    {new Date(event.date).toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </View>
                <View style={styles.eventContent}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  {event.description ? (
                    <Text style={styles.eventDesc} numberOfLines={1}>{event.description}</Text>
                  ) : null}
                </View>
                <View style={[styles.eventAccent, { backgroundColor: COLORS.primary }]} />
              </TouchableOpacity>
            ))
          )}
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>

      {/* Modal */}
      <Modal visible={modalVisible} animationType="slide" transparent>
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={{ flex: 1 }}>
          <TouchableOpacity style={styles.modalOverlay} activeOpacity={1} onPress={() => setModalVisible(false)} />
          <View style={styles.modalSheet}>
            <View style={styles.modalHandle} />
            <Text style={styles.modalTitle}>{editingEvent ? 'Edit Event' : 'New Event'}</Text>

            <TextInput
              style={styles.input}
              placeholder="Event title"
              placeholderTextColor={COLORS.muted}
              value={newTitle}
              onChangeText={setNewTitle}
              autoFocus
            />

            <TextInput
              style={[styles.input, { height: 80 }]}
              placeholder="Description (optional)"
              placeholderTextColor={COLORS.muted}
              value={newDesc}
              onChangeText={setNewDesc}
              multiline
              textAlignVertical="top"
            />

            <TouchableOpacity style={styles.dateBtn} onPress={() => setShowTimePicker(true)}>
              <Ionicons name="time-outline" size={18} color={COLORS.primary} />
              <Text style={styles.dateBtnText}>
                {eventDate.toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit' })}
              </Text>
            </TouchableOpacity>

            {showTimePicker && (
              <DateTimePicker
                value={eventDate}
                mode="time"
                display="default"
                onChange={(e, d) => {
                  setShowTimePicker(false);
                  if (d) setEventDate(d);
                }}
              />
            )}

            <Text style={styles.reminderHint}>
              🔔 You'll receive a reminder 30 minutes before the event
            </Text>

            <TouchableOpacity
              style={[styles.addBtn, !newTitle.trim() && styles.addBtnDisabled]}
              onPress={saveEvent}
              disabled={!newTitle.trim()}
            >
              <Text style={styles.addBtnText}>{editingEvent ? 'Update Event' : 'Add Event'}</Text>
            </TouchableOpacity>
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.darker },
  monthHeader: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md,
  },
  monthTitle: { color: COLORS.text, fontSize: 20, fontWeight: '800' },
  navBtn: { padding: 8 },
  dayNames: {
    flexDirection: 'row', paddingHorizontal: SPACING.sm, marginBottom: 4,
  },
  dayName: {
    flex: 1, textAlign: 'center', color: COLORS.muted,
    fontSize: 12, fontWeight: '700', textTransform: 'uppercase',
  },
  grid: {
    flexDirection: 'row', flexWrap: 'wrap',
    paddingHorizontal: SPACING.sm,
  },
  cell: {
    width: `${100 / 7}%`, aspectRatio: 1,
    alignItems: 'center', justifyContent: 'center',
    borderRadius: 12,
  },
  cellToday: { backgroundColor: COLORS.surface },
  cellSelected: { backgroundColor: COLORS.primary },
  cellText: { color: COLORS.textSecondary, fontSize: 15, fontWeight: '500' },
  cellTextToday: { color: COLORS.primary, fontWeight: '800' },
  cellTextSelected: { color: '#fff', fontWeight: '800' },
  eventDot: {
    width: 5, height: 5, borderRadius: 3,
    backgroundColor: COLORS.primary, marginTop: 2,
  },
  eventsSection: { padding: SPACING.md },
  eventsSectionHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: SPACING.md,
  },
  eventsTitle: {
    color: COLORS.text, fontSize: 16, fontWeight: '700',
    textTransform: 'capitalize',
  },
  addEventBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: COLORS.primary + '22', paddingHorizontal: 12,
    paddingVertical: 6, borderRadius: 10,
  },
  addEventText: { color: COLORS.primary, fontWeight: '700', fontSize: 13 },
  noEvents: { alignItems: 'center', padding: SPACING.xl },
  noEventsText: { color: COLORS.muted, fontSize: 14 },
  eventItem: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: COLORS.surface, borderRadius: 14,
    padding: SPACING.md, marginBottom: SPACING.sm, gap: SPACING.sm,
    overflow: 'hidden',
  },
  eventAccent: { position: 'absolute', left: 0, top: 0, bottom: 0, width: 4 },
  eventTime: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8,
  },
  eventTimeText: { color: COLORS.primary, fontSize: 12, fontWeight: '700' },
  eventContent: { flex: 1 },
  eventTitle: { color: COLORS.text, fontWeight: '700', fontSize: 15 },
  eventDesc: { color: COLORS.muted, fontSize: 12, marginTop: 2 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.6)' },
  modalSheet: {
    backgroundColor: COLORS.surface,
    borderTopLeftRadius: 24, borderTopRightRadius: 24,
    padding: SPACING.lg, paddingBottom: 40,
  },
  modalHandle: {
    width: 40, height: 4, backgroundColor: COLORS.border,
    borderRadius: 2, alignSelf: 'center', marginBottom: SPACING.md,
  },
  modalTitle: { color: COLORS.text, fontSize: 20, fontWeight: '800', marginBottom: SPACING.md },
  input: {
    backgroundColor: COLORS.darker, color: COLORS.text,
    borderRadius: 12, padding: SPACING.md, fontSize: 16,
    marginBottom: SPACING.sm, borderWidth: 1, borderColor: COLORS.border,
  },
  dateBtn: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.darker, borderRadius: 12, padding: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border, marginBottom: SPACING.sm,
  },
  dateBtnText: { color: COLORS.textSecondary, fontSize: 15 },
  reminderHint: {
    color: COLORS.muted, fontSize: 12, textAlign: 'center',
    marginBottom: SPACING.md,
  },
  addBtn: {
    backgroundColor: COLORS.primary, borderRadius: 14,
    padding: SPACING.md, alignItems: 'center',
  },
  addBtnDisabled: { opacity: 0.4 },
  addBtnText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
