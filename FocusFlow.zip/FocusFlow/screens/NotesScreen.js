import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, FlatList, TextInput, TouchableOpacity,
  StyleSheet, Modal, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SPACING } from '../constants/theme';
import { Storage, KEYS } from '../utils/storage';

const NOTE_COLORS = ['#FF6B35', '#E94560', '#7C4DFF', '#00BCD4', '#4CAF50', '#FFC107'];

function NoteCard({ note, onPress, onDelete }) {
  return (
    <TouchableOpacity
      style={[styles.card, { borderLeftColor: note.color || COLORS.primary }]}
      onPress={() => onPress(note)}
      onLongPress={() => onDelete(note.id)}
      activeOpacity={0.8}
    >
      <Text style={styles.cardTitle} numberOfLines={1}>{note.title || 'Untitled'}</Text>
      <Text style={styles.cardBody} numberOfLines={3}>{note.body}</Text>
      <Text style={styles.cardDate}>
        {new Date(note.updatedAt).toLocaleDateString('it-IT', { day: '2-digit', month: 'short', year: 'numeric' })}
      </Text>
    </TouchableOpacity>
  );
}

export default function NotesScreen() {
  const [notes, setNotes] = useState([]);
  const [editingNote, setEditingNote] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [color, setColor] = useState(NOTE_COLORS[0]);
  const [search, setSearch] = useState('');

  useEffect(() => { loadNotes(); }, []);

  async function loadNotes() {
    const saved = await Storage.get(KEYS.NOTES);
    if (saved) setNotes(saved);
  }

  async function saveNote() {
    if (!body.trim() && !title.trim()) return;

    const now = new Date().toISOString();
    let updated;

    if (editingNote) {
      updated = notes.map(n => n.id === editingNote.id
        ? { ...n, title, body, color, updatedAt: now }
        : n
      );
    } else {
      const newNote = {
        id: Date.now().toString(),
        title,
        body,
        color,
        createdAt: now,
        updatedAt: now,
      };
      updated = [newNote, ...notes];
    }

    setNotes(updated);
    await Storage.set(KEYS.NOTES, updated);
    closeModal();
  }

  function openNote(note) {
    setEditingNote(note);
    setTitle(note.title);
    setBody(note.body);
    setColor(note.color || NOTE_COLORS[0]);
    setModalVisible(true);
  }

  function newNote() {
    setEditingNote(null);
    setTitle('');
    setBody('');
    setColor(NOTE_COLORS[0]);
    setModalVisible(true);
  }

  function closeModal() {
    setModalVisible(false);
    setEditingNote(null);
  }

  function deleteNote(id) {
    Alert.alert('Delete Note', 'Remove this note permanently?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete', style: 'destructive',
        onPress: async () => {
          const updated = notes.filter(n => n.id !== id);
          setNotes(updated);
          await Storage.set(KEYS.NOTES, updated);
        }
      }
    ]);
  }

  const filtered = notes.filter(n =>
    n.title.toLowerCase().includes(search.toLowerCase()) ||
    n.body.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={styles.container}>
      {/* Search */}
      <View style={styles.searchBar}>
        <Ionicons name="search" size={18} color={COLORS.muted} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search notes..."
          placeholderTextColor={COLORS.muted}
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color={COLORS.muted} />
          </TouchableOpacity>
        )}
      </View>

      <FlatList
        data={filtered}
        keyExtractor={item => item.id}
        numColumns={2}
        renderItem={({ item }) => (
          <View style={{ flex: 1, margin: 6 }}>
            <NoteCard note={item} onPress={openNote} onDelete={deleteNote} />
          </View>
        )}
        contentContainerStyle={{ padding: SPACING.sm, paddingBottom: 100 }}
        ListEmptyComponent={
          <View style={styles.emptyState}>
            <Text style={styles.emptyIcon}>📝</Text>
            <Text style={styles.emptyText}>No notes yet</Text>
            <Text style={styles.emptySubtext}>Tap + to capture your thoughts</Text>
          </View>
        }
      />

      <TouchableOpacity style={styles.fab} onPress={newNote}>
        <Ionicons name="add" size={30} color="#fff" />
      </TouchableOpacity>

      <Modal visible={modalVisible} animationType="slide" transparent>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={{ flex: 1 }}
        >
          <View style={styles.modalFull}>
            {/* Header */}
            <View style={styles.modalHeader}>
              <TouchableOpacity onPress={closeModal} style={styles.headerBtn}>
                <Ionicons name="chevron-down" size={24} color={COLORS.muted} />
              </TouchableOpacity>
              <Text style={styles.modalHeaderTitle}>
                {editingNote ? 'Edit Note' : 'New Note'}
              </Text>
              <TouchableOpacity onPress={saveNote} style={styles.saveBtn}>
                <Text style={styles.saveBtnText}>Save</Text>
              </TouchableOpacity>
            </View>

            {/* Color picker */}
            <View style={styles.colorRow}>
              {NOTE_COLORS.map(c => (
                <TouchableOpacity
                  key={c}
                  style={[styles.colorDot, { backgroundColor: c }, color === c && styles.colorDotActive]}
                  onPress={() => setColor(c)}
                />
              ))}
            </View>

            <TextInput
              style={styles.titleInput}
              placeholder="Title"
              placeholderTextColor={COLORS.muted}
              value={title}
              onChangeText={setTitle}
              maxLength={60}
            />
            <TextInput
              style={styles.bodyInput}
              placeholder="Write your note..."
              placeholderTextColor={COLORS.muted}
              value={body}
              onChangeText={setBody}
              multiline
              textAlignVertical="top"
              autoFocus={!editingNote}
            />
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.darker },
  searchBar: {
    flexDirection: 'row', alignItems: 'center', gap: SPACING.sm,
    backgroundColor: COLORS.surface, margin: SPACING.md,
    borderRadius: 14, paddingHorizontal: SPACING.md,
    borderWidth: 1, borderColor: COLORS.border,
  },
  searchInput: { flex: 1, color: COLORS.text, fontSize: 15, paddingVertical: 12 },
  card: {
    backgroundColor: COLORS.surface, borderRadius: 14,
    padding: SPACING.md, borderLeftWidth: 4,
    elevation: 2, minHeight: 100,
  },
  cardTitle: { color: COLORS.text, fontWeight: '700', fontSize: 15, marginBottom: 4 },
  cardBody: { color: COLORS.textSecondary, fontSize: 13, lineHeight: 18, flex: 1 },
  cardDate: { color: COLORS.muted, fontSize: 11, marginTop: 8 },
  emptyState: { alignItems: 'center', paddingTop: 80 },
  emptyIcon: { fontSize: 48, marginBottom: SPACING.md },
  emptyText: { color: COLORS.text, fontSize: 18, fontWeight: '700' },
  emptySubtext: { color: COLORS.muted, marginTop: 4 },
  fab: {
    position: 'absolute', bottom: 24, right: 24,
    width: 60, height: 60, borderRadius: 30,
    backgroundColor: COLORS.primary, justifyContent: 'center', alignItems: 'center',
    elevation: 8, shadowColor: COLORS.primary, shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4, shadowRadius: 8,
  },
  modalFull: {
    flex: 1, backgroundColor: COLORS.darker,
    marginTop: 60, borderTopLeftRadius: 24, borderTopRightRadius: 24,
  },
  modalHeader: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    padding: SPACING.md, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerBtn: { padding: 6 },
  modalHeaderTitle: { color: COLORS.text, fontSize: 17, fontWeight: '700' },
  saveBtn: {
    backgroundColor: COLORS.primary, paddingHorizontal: SPACING.md,
    paddingVertical: 8, borderRadius: 10,
  },
  saveBtnText: { color: '#fff', fontWeight: '700', fontSize: 14 },
  colorRow: {
    flexDirection: 'row', gap: 10, padding: SPACING.md, paddingBottom: SPACING.sm,
  },
  colorDot: {
    width: 28, height: 28, borderRadius: 14,
  },
  colorDotActive: {
    borderWidth: 3, borderColor: '#fff',
  },
  titleInput: {
    color: COLORS.text, fontSize: 22, fontWeight: '800',
    paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  bodyInput: {
    flex: 1, color: COLORS.text, fontSize: 16, lineHeight: 26,
    padding: SPACING.md,
  },
});
