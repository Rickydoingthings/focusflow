import AsyncStorage from '@react-native-async-storage/async-storage';

export const Storage = {
  async get(key) {
    try {
      const value = await AsyncStorage.getItem(key);
      return value ? JSON.parse(value) : null;
    } catch (e) {
      console.error('Storage.get error:', e);
      return null;
    }
  },

  async set(key, value) {
    try {
      await AsyncStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage.set error:', e);
    }
  },

  async remove(key) {
    try {
      await AsyncStorage.removeItem(key);
    } catch (e) {
      console.error('Storage.remove error:', e);
    }
  },
};

export const KEYS = {
  TODOS: 'focusflow_todos',
  NOTES: 'focusflow_notes',
  EVENTS: 'focusflow_events',
};
