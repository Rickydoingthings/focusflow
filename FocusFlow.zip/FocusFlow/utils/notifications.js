import * as Notifications from 'expo-notifications';

export async function scheduleTaskReminder(task, date) {
  if (!date) return null;

  try {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: '🎯 Task Reminder',
        body: task.title,
        data: { taskId: task.id },
        sound: true,
      },
      trigger: {
        date: new Date(date),
      },
    });
    return id;
  } catch (e) {
    console.error('scheduleTaskReminder error:', e);
    return null;
  }
}

export async function scheduleEventReminder(event) {
  if (!event.date) return null;

  const reminderDate = new Date(event.date);
  reminderDate.setMinutes(reminderDate.getMinutes() - 30); // 30 min before

  if (reminderDate <= new Date()) return null;

  try {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: '📅 Event Reminder',
        body: `"${event.title}" starts in 30 minutes`,
        data: { eventId: event.id },
        sound: true,
      },
      trigger: {
        date: reminderDate,
      },
    });
    return id;
  } catch (e) {
    console.error('scheduleEventReminder error:', e);
    return null;
  }
}

export async function cancelNotification(notificationId) {
  if (!notificationId) return;
  try {
    await Notifications.cancelScheduledNotificationAsync(notificationId);
  } catch (e) {
    console.error('cancelNotification error:', e);
  }
}

export async function sendInstantNotification(title, body) {
  await Notifications.scheduleNotificationAsync({
    content: { title, body, sound: true },
    trigger: null,
  });
}
